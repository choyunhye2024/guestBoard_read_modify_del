
package com.peisia.dto;

public class Header {

	public String resultCode;
	public String resultMsg;

}
