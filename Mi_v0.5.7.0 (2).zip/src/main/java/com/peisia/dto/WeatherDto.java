
package com.peisia.dto;

public class WeatherDto {

	public Response response;

}
