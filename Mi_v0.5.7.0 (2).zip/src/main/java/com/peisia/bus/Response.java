
package com.peisia.bus;

public class Response {

	public Header header;
	public Body body;

}
