
package com.peisia.bus;

public class Header {

	public String resultCode;
	public String resultMsg;

}
