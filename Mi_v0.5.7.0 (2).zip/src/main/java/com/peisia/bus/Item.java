
package com.peisia.bus;

public class Item {

	public String statDate;
	public String routeName;
	public String sectionName;
	public String totalOperatingTime;
	public String hour00;
	public String hour01;
	public String hour02;
	public String hour03;
	public String hour04;
	public String hour05;
	public String hour06;
	public String hour07;
	public String hour08;
	public String hour09;
	public String hour10;
	public String hour11;
	public String hour12;
	public String hour13;
	public String hour14;
	public String hour15;
	public String hour16;
	public String hour17;
	public String hour18;
	public String hour19;
	public String hour20;
	public String hour21;
	public String hour22;
	public String hour23;

}
