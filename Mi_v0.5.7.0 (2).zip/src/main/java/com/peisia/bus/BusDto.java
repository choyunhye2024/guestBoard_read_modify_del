
package com.peisia.bus;

public class BusDto {

	public Response response;

}
